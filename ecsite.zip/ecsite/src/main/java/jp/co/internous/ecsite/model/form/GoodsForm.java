package jp.co.internous.ecsite.model.form;

import java.io.Serializable;

public class GoodsForm implements Serializable{

	private int id;
	private String goodsName;
	private int price;
	
	public int getId() {
		retrun id;
	}
	public void setId(int Id) {
		this.id = id;
	}
	public String getGoodsName() {
		retrun goodsName;
	}
	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}
	public int getPrice() {
		retrun price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
}
